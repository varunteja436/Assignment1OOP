package oct26;

public class Q34 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i = 1;
		
		while(i<10) {
			int j =1;
			while(j<11) {
			System.out.print(i*j+ " ");
			j++;
		}
			System.out.println("");
			i++;
		}
	}

}
