package oct26;

public class Q29 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int count= 1;
		while(count <= 10) {
			System.out.print(count + " ");
			count++;
		}
	}

}
