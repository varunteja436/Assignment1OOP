package oct26;

public class Q28 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
